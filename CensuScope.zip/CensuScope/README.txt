CensuScope V1.0 README
=====================================
Contact Me: Amir Shams
Email : amir.shams84@gmail.com

What is CensuScope?
------------------------
* CensuScope is designed and optimized for the quick detection the components of a given NGS metagenomic data and providing users
  with a standard format report of components into species resolution.

  The core of the CensuScope consists of census-based children reads file generating and blast/bowtie based short-reads alignment. 
  So the customized CensuScope can be capable of sample contamination evaluation, Microbiome components detection and other meta'omic
  related data analysis.
  
  
Installation instructions: 
-----------------------------------------------------------------------

* you have to have BLAST-NT database as reference , we already prepared BLAST-NT and concatenate them
   together , you can download all the packages from this link :http://hive.biochemistry.gwu.edu/data.php 
   when the the download has finished(it is a zip folder with 11.0 GB size containg all required file)
   extract the compressed folder(CensuScope.zip) into your system for example on C:\ Directory
   
   the compressed folder include BLAST-NT database(17GB) and Blastn software and two 
   Synthetic reads out of virus and prokaryotes(v1.fastq and p1.fastq) for testing

How to use CensuScope V1.0?
---------------------------
<< It is recommended that you use a computer with RAM capacity more than 1GB>>

  1. run CensuScope v1.0.exe
  
  2. set the path of your source file( for example c:\CensuScope\source\v1.fastq)
  
  3. set the path of CensuScope Package where you extracted it.(for example c:\ or d:\desktop)
     
  4. set the number of iterations and set the size of sample 
  
  4. press submit and wait...
  
  5. the output will be generated on this address .\CensuScope\sample\

<<VERSION Beta is  Designed for SYSTEMS with more than 10 cores of cpu >>

THE OUTPUT
-----------------------------

* Final result comes into 4 different files (3 csv and 1 txt)

  1. log.txt
     this text file provide all parameters which have been used to run and generate the result
  
  2. gi_centric_table.csv
     GI_numbers sorted result
    
  3. tax_centric_table.csv
      TAX_ID Sorted result
   
  4. taxslim_centric_table.csv
      Kingdom-depth taxonomy sorted result
  